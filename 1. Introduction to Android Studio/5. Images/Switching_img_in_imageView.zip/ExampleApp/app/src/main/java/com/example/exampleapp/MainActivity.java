 package com.example.exampleapp;

//this contains the code for Activity which contains an action bar
import  androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;//bundle for android OS
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

 public class MainActivity extends AppCompatActivity {
     boolean ispressed = false;
    public void clickFunction(View view) {
        ImageView image = (ImageView) findViewById(R.id.catImage);
        if(!ispressed){
            image.setImageResource(R.drawable.cat2);
            ispressed = true;
        }else{
            image.setImageResource(R.drawable.cat1);
            ispressed = false;
        }

        Toast.makeText(this, "Image Switched!!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}