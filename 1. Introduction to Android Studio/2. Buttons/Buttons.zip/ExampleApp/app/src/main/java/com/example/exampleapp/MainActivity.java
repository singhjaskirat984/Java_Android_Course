 package com.example.exampleapp;

//this contains the code for Activity which contains an action bar
import  androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;//bundle for android OS
import android.util.Log;
import android.view.View;

 public class MainActivity extends AppCompatActivity {

    public void clickFunction(View view) {
        System.out.println("Button Pressed");
        Log.i("info", "Button Pressed");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}