 package com.example.exampleapp;

//this contains the code for Activity which contains an action bar
import  androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;//bundle for android OS
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

 public class MainActivity extends AppCompatActivity {
     Random rand = new Random();
     // Generate random integers in range 0 to 999
     int rand_int1 = rand.nextInt(20);
     String Result="";
    public void clickFunction(View view) {
        EditText currency = (EditText) findViewById(R.id.currencyTxt);
        int value = Integer.parseInt(currency.getText().toString());
        if(rand_int1 == value){
            Result = "Right Guess!!";
        }else if(value < rand_int1){
            Result = "Go Higher!!";
        }else if(value > rand_int1){
            Result = "Go Lower!!";
        }

        Toast.makeText(this, Result, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}