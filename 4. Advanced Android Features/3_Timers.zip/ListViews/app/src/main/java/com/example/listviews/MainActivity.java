package com.example.listviews;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//1st Method:
//        //object handler
//        final Handler handler = new Handler();
//
//        //runnable function
//        Runnable run = new Runnable() {
//            @Override
//            public void run() {
//                Log.i("hey its us", "A second passes by");
//
//                handler.postDelayed(this, 1000);
//            }
//        };
//
//        //using handler run called
//        handler.post(run);

// 2nd Method:
        new CountDownTimer(10000, 1000){
          public void onTick(long millisecondsUntilDone){
              Log.i("Seconds Left!", String.valueOf(millisecondsUntilDone/1000));
              System.out.println("Seconds Left!"+millisecondsUntilDone/1000);
          }

          public void onFinish(){
              Log.i("we're Done", "no more countdown");
              System.out.println("we're Done"+"no more countdown");
          }
        };

    }
}