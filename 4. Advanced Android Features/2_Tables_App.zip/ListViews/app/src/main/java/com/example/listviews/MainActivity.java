package com.example.listviews;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SeekBar numberSeekBar = findViewById(R.id.NumberSeekBar);

        ListView tableListView = findViewById(R.id.myListView);

        ArrayList<String> tableList = new ArrayList<String>();

        numberSeekBar.setMax(20);
        numberSeekBar.setMin(1);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, tableList);

        for (int i=1; i<=10; i++) {
            int ans = i;
            String result = Integer.toString(ans);
            tableList.add(result);
        }
        tableListView.setAdapter(arrayAdapter);

        numberSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tableList.clear();
                for (int i=1; i<=10; i++) {
                    int ans = i * progress;
                    String result = Integer.toString(ans);
                    tableList.add(result);
                }
                tableListView.setAdapter(arrayAdapter);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



    }
}