package com.example.listviews;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView modelListView = findViewById(R.id.myListView);

        ArrayList<String> modelsList = new ArrayList<String>();

        modelsList.add("Youngs");
        modelsList.add("Carter");
        modelsList.add("Foxx");
        modelsList.add("Vox");
        modelsList.add("May");
        modelsList.add("marks");
        modelsList.add("silver");
        modelsList.add("brooks");
        modelsList.add("blossom");
        modelsList.add("roy");
        modelsList.add("perez");
        modelsList.add("nevada");
        modelsList.add("steele");
        modelsList.add("elfie");
        modelsList.add("rost");
        modelsList.add("flower");
        modelsList.add("stone");
        modelsList.add("La");
        modelsList.add("hard");
        modelsList.add("kay");
        modelsList.add("steele");
        modelsList.add("Rrisingstar");
        modelsList.add("Devine");
        modelsList.add("risingstar");
        modelsList.add("summers");
        modelsList.add("gunner");
        modelsList.add("moreno");
        modelsList.add("land");
        modelsList.add("lord");
        modelsList.add("Monday");
        modelsList.add("Michael jackson");
        modelsList.add("Steele");


        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, modelsList);

        modelListView.setAdapter(arrayAdapter);

        modelListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //AdapterView<?> parent: refers to whole ListView
                //View view: refers to one item in List View
                //int position: Give the Position of one List Item
                //long id: Usage Unknown very less usage
                Log.i("Person name: ", modelsList.get(position));
                Toast.makeText(MainActivity.this, modelsList.get(position), Toast.LENGTH_SHORT).show();
            }
        });
    }
}