package com.example.game_connect_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    // 0: Circle, 1: Cross, 2: Empty
    int activePlayer = 0;
    int [] gameState = {2,2,2,2,2,2,2,2,2};
    int [][] winningPositions = {{0,1,2}, {3,4,5}, {6,7,8,}, {0,3,6}, {1,4,7}, {2,5,8}, {0,4,8}, {2,4,6}};
    boolean gameActive = true;

    public void playAgain(View view){
        //basically on click of playAgain we set all vars and UI to their default value which is same as initial state of app
        //i.e when app first starts
        //and then when someone clicks on one cell dropIn method is call which means now game can be played again
        //play again button set back to invisible
        Button play = (Button) findViewById(R.id.playAgainButton);
        play.setVisibility(View.INVISIBLE);
        //Gridlayout images set to invisible
        androidx.gridlayout.widget.GridLayout gridLayout = findViewById(R.id.gridLayout);
        for(int i=0; i<gridLayout.getChildCount(); i++){
            ImageView img = (ImageView) gridLayout.getChildAt(i);
            img.setImageDrawable(null);
        }
        //activePlayer set to default value
        activePlayer = 0;
        //gamestate array set to default value which is same as app when first started
        Arrays.fill(gameState, 2);
        //gameactive  set to default value which is true and which is same as app when first started
        gameActive = true;
    }

    //always called when someone taps on one imageview inside one tic tac toe cell
    public void dropIn(View view) {
        ImageView circleCross = (ImageView) view;
        int tappedTag = Integer.parseInt(circleCross.getTag().toString());
        if (gameState[tappedTag] == 2 && gameActive){
            gameState[tappedTag] = activePlayer;
            circleCross.setTranslationY(-1500);
            if(activePlayer == 0){
                circleCross.setImageResource(R.drawable.circle);
                circleCross.animate().translationYBy(1500).rotation(3600).setDuration(300);
                activePlayer = 1;
            }else{
                circleCross.setImageResource(R.drawable.cross);
                activePlayer = 0;
                circleCross.animate().translationYBy(1500).rotation(3600).setDuration(300);
            }

            for(int [] winningPosition : winningPositions ){
                if(gameState[winningPosition[0]]==gameState[winningPosition[1]] && gameState[winningPosition[1]]==gameState[winningPosition[2]] && gameState[winningPosition[0]]!=2){
                    gameActive = false;
                    String winner="";
                    if(activePlayer==1){
                        winner = "Circle";
                    }else{
                        winner = "Cross";
                    }

                    Button play = (Button) findViewById(R.id.playAgainButton);
                    play.setVisibility(View.VISIBLE);
                    Toast.makeText(this,  winner + " has won", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}