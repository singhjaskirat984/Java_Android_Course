package com.example.video;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.VideoView;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

//    Timer t = new Timer();

    //media player created inside class-1
    MediaPlayer mediaPlayer;
    AudioManager audioManager;

    //started inside play method-3
    public void play(View view){
        mediaPlayer.start();
    }

    //paused inside pause method-4
    public void pause(View view){
//        t.cancel();
//        t.purge();
        mediaPlayer.pause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        mediaPlayer = MediaPlayer.create(this, R.raw.cheer);
//        mediaPlayer.start();
        //setup inside onCreate method-2
        //mediaPlayer setup/created here bcoz if pause clicked on before creating the mediaplayer the app would crash
        mediaPlayer = MediaPlayer.create(this, R.raw.cheer);

        //audio manager initialized
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        //seekbar object created and initialized
        SeekBar volumeController = (SeekBar) findViewById(R.id.volumeSeekBar);

        //current volume of device extracted
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        //max volume of device extracted
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        //slider's max value set to that of device's max volume
        volumeController.setMax(maxVolume);
        //slider's current position set to that of device's current music volume
        volumeController.setProgress(currentVolume);

        volumeController.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                 audioManager.setStreamVolume(AudioManager.STREAM_MUSIC,progress,0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //seekbar object created and initialized
        SeekBar scrubController = (SeekBar) findViewById(R.id.scrubSeekBar);

        scrubController.setMax(mediaPlayer.getDuration());

        scrubController.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                Log.i("Seekbar CHanged", Integer.toString(progress));
                mediaPlayer.seekTo(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        new Timer().scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                scrubController.setProgress(mediaPlayer.getCurrentPosition());
            }
        },0,300);
    }
}