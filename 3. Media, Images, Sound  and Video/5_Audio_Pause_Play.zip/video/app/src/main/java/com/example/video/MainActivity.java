package com.example.video;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    //media player created inside class-1
    MediaPlayer mediaPlayer;

    //started inside play method-3
    public void play(View view){
        mediaPlayer.start();
    }

    //paused inside pause method-4
    public void pause(View view){
        mediaPlayer.pause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        mediaPlayer = MediaPlayer.create(this, R.raw.cheer);
//        mediaPlayer.start();
        //setup inside onCreate method-2
        //mediaPlayer setup/created here bcoz if pause clicked on before creating the mediaplayer the app would crash
        mediaPlayer = MediaPlayer.create(this, R.raw.cheer);
    }
}